import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Pokemon } from '../models/pokemon';
import { GrassPokemonService } from '../services/grass-pokemon';

@Component({
  selector: 'app-grass-pokemon',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './grass-pokemon.html',
  styleUrls: ['./grass-pokemon.css']
})
export class GrassPokemonComponent implements OnInit {
  currentPokemon!: Pokemon;
  currentStage: number = 1;

  constructor(private grassService: GrassPokemonService) {}

  ngOnInit(): void {
    this.loadPokemon(1);
  }

  loadPokemon(stage: number): void {
    this.currentPokemon = this.grassService.getPokemonByEvolutionStage(stage);
    this.currentStage = stage;
  }

  evolve(): void {
    if (this.currentStage < 3) {
      this.loadPokemon(this.currentStage + 1);
    }
  }

  revert(): void {
    if (this.currentStage > 1) {
      this.loadPokemon(this.currentStage - 1);
    }
  }
}