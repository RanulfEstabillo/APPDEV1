import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Pokemon } from '../models/pokemon';
import { WaterPokemonService } from '../services/water-pokemon';

@Component({
  selector: 'app-water-pokemon',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './water-pokemon.html',
  styleUrls: ['./water-pokemon.css']
})
export class WaterPokemonComponent implements OnInit {
  currentPokemon!: Pokemon;
  currentStage: number = 1;

  constructor(private waterService: WaterPokemonService) {}

  ngOnInit(): void {
    this.loadPokemon(1);
  }

  loadPokemon(stage: number): void {
    this.currentPokemon = this.waterService.getPokemonByEvolutionStage(stage);
    this.currentStage = stage;
  }

  evolve(): void {
    if (this.currentStage < 3) {
      this.loadPokemon(this.currentStage + 1);
    }
  }

  revert(): void {
    if (this.currentStage > 1) {
      this.loadPokemon(this.currentStage - 1);
    }
  }
}