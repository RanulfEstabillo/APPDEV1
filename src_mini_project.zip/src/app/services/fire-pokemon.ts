import { Injectable } from '@angular/core';
import { Pokemon } from '../models/pokemon';

@Injectable({
  providedIn: 'root'
})
export class FirePokemonService {
  private pokemons: Pokemon[] = [
    {
      id: 1, name: 'Cyndaquil', healthPoints: 39, attack: 52, defense: 43,
      specialAttack: 60, specialDefense: 50, speed: 65, typing: ['Fire']
    },
    {
      id: 2, name: 'Quilava', healthPoints: 58, attack: 64, defense: 58,
      specialAttack: 80, specialDefense: 65, speed: 80, typing: ['Fire']
    },
    {
      id: 3, name: 'Typhlosion', healthPoints: 78, attack: 84, defense: 78,
      specialAttack: 109, specialDefense: 85, speed: 100, typing: ['Fire']
    }
  ];

  getPokemonByEvolutionStage(stage: number): Pokemon {
    return this.pokemons[stage - 1];
  }
}