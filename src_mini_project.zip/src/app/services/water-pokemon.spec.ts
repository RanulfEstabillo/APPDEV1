import { TestBed } from '@angular/core/testing';

import { WaterPokemon } from './water-pokemon';

describe('WaterPokemon', () => {
  let service: WaterPokemon;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WaterPokemon);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
