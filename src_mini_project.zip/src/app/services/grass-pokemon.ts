import { Injectable } from '@angular/core';
import { Pokemon } from '../models/pokemon';

@Injectable({
  providedIn: 'root'
})
export class GrassPokemonService {
  private pokemons: Pokemon[] = [
    {
      id: 1, name: 'Chikorita', healthPoints: 45, attack: 49, defense: 65,
      specialAttack: 49, specialDefense: 65, speed: 45, typing: ['Grass']
    },
    {
      id: 2, name: 'Bayleef', healthPoints: 60, attack: 62, defense: 80,
      specialAttack: 63, specialDefense: 80, speed: 60, typing: ['Grass']
    },
    {
      id: 3, name: 'Meganium', healthPoints: 80, attack: 82, defense: 100,
      specialAttack: 83, specialDefense: 100, speed: 80, typing: ['Grass']
    }
  ];

  getPokemonByEvolutionStage(stage: number): Pokemon {
    return this.pokemons[stage - 1];
  }
}