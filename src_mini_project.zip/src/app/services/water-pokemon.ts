import { Injectable } from '@angular/core';
import { Pokemon } from '../models/pokemon';

@Injectable({
  providedIn: 'root'
})
export class WaterPokemonService {
  private pokemons: Pokemon[] = [
    {
      id: 1, name: 'Totodile', healthPoints: 50, attack: 65, defense: 64,
      specialAttack: 44, specialDefense: 48, speed: 43, typing: ['Water']
    },
    {
      id: 2, name: 'Croconaw', healthPoints: 65, attack: 80, defense: 80,
      specialAttack: 59, specialDefense: 63, speed: 58, typing: ['Water']
    },
    {
      id: 3, name: 'Feraligatr', healthPoints: 85, attack: 105, defense: 100,
      specialAttack: 79, specialDefense: 83, speed: 78, typing: ['Water']
    }
  ];

  getPokemonByEvolutionStage(stage: number): Pokemon {
    return this.pokemons[stage - 1];
  }
}