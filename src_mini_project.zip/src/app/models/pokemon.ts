export interface Pokemon {
  id: number;
  name: string;
  healthPoints: number;
  attack: number;
  defense: number;
  specialAttack: number;
  specialDefense: number;
  speed: number;
  typing: string[];
}