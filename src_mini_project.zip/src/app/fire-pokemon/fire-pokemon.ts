import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Pokemon } from '../models/pokemon';
import { FirePokemonService } from '../services/fire-pokemon';

@Component({
  selector: 'app-fire-pokemon',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './fire-pokemon.html',
  styleUrls: ['./fire-pokemon.css']
})
export class FirePokemonComponent implements OnInit {
  currentPokemon!: Pokemon;
  currentStage: number = 1;

  constructor(private fireService: FirePokemonService) {}

  ngOnInit(): void {
    this.loadPokemon(1);
  }

  loadPokemon(stage: number): void {
    this.currentPokemon = this.fireService.getPokemonByEvolutionStage(stage);
    this.currentStage = stage;
  }

  evolve(): void {
    if (this.currentStage < 3) {
      this.loadPokemon(this.currentStage + 1);
    }
  }

  revert(): void {
    if (this.currentStage > 1) {
      this.loadPokemon(this.currentStage - 1);
    }
  }
}