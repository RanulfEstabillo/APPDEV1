import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WaterPokemonComponent } from './water-pokemon/water-pokemon';
import { FirePokemonComponent } from './fire-pokemon/fire-pokemon';
import { GrassPokemonComponent } from './grass-pokemon/grass-pokemon';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, WaterPokemonComponent, FirePokemonComponent, GrassPokemonComponent],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {
  title = 'Johto-Starters';
}