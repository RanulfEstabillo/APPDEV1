import { Component, OnInit } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { BerriesService, Berry } from '../services/berries';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-berries',
  standalone: true,
  imports: [MatTableModule, RouterModule],
  templateUrl: './berries.html',
  styleUrls: ['./berries.css']
})
export class BerriesComponent implements OnInit {
  dataSource: Berry[] = [];
  displayedColumns: string[] = ['name', 'effect', 'rarity'];

  constructor(private berriesService: BerriesService) {}

  ngOnInit(): void {
    this.dataSource = this.berriesService.getBerries();
  }
}