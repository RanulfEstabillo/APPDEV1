import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { GymLeadersService, GymLeader } from '../services/gym-leaders';

@Component({
  selector: 'app-falkner',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './falkner.html',
  styleUrls: ['./falkner.css']
})
export class FalknerComponent implements OnInit {
  gymLeader!: GymLeader;

  constructor(private gymLeadersService: GymLeadersService) {}

  ngOnInit(): void {
    const leader = this.gymLeadersService.getGymLeaderByName('Falkner');
    if (leader) {
      this.gymLeader = leader;
    }
  }
}