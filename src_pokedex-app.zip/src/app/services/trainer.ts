import { Injectable } from '@angular/core';

export interface Trainer {
  name: string;
  age: string;
  address: string;
  favoritePokemon: string;
  pokemonTeam: string[];
}

@Injectable({
  providedIn: 'root'
})
export class TrainerService {
  private trainers: Trainer[] = [];

  constructor() { }

  addTrainer(trainer: Trainer): void {
    this.trainers.push(trainer);
  }

  getTrainers(): Trainer[] {
    return this.trainers;
  }

  clearTrainers(): void {
    this.trainers = [];
  }
}