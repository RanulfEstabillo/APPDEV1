import { TestBed } from '@angular/core/testing';

import { Pokeballs } from './pokeballs';

describe('Pokeballs', () => {
  let service: Pokeballs;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Pokeballs);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
