import { Injectable } from '@angular/core';

export interface Pokeball {
  name: string;
  catchRate: string;
  description: string;
}

@Injectable({
  providedIn: 'root'
})
export class PokeballsService {
  constructor() { }

  getPokeballs(): Pokeball[] {
    return [
      { name: 'Poké Ball', catchRate: '1×', description: 'A device for catching wild Pokémon' },
      { name: 'Great Ball', catchRate: '1.5×', description: 'A good ball with a higher catch rate' },
      { name: 'Ultra Ball', catchRate: '2×', description: 'A better ball with a high catch rate' },
      { name: 'Master Ball', catchRate: '255×', description: 'The best ball - catches any Pokémon' },
      { name: 'Safari Ball', catchRate: '1.5×', description: 'Used in the Safari Zone' },
      { name: 'Level Ball', catchRate: '1-8×', description: 'Better for lower level Pokémon' },
      { name: 'Lure Ball', catchRate: '3×', description: 'Better for Pokémon caught by fishing' },
      { name: 'Moon Ball', catchRate: '4×', description: 'Better for Pokémon that evolve with Moon Stone' }
    ];
  }
}