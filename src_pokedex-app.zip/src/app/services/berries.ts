import { Injectable } from '@angular/core';

export interface Berry {
  name: string;
  effect: string;
  rarity: string;
}

@Injectable({
  providedIn: 'root'
})
export class BerriesService {
  constructor() { }

  getBerries(): Berry[] {
    return [
      { name: 'Oran Berry', effect: 'Restores 10 HP', rarity: 'Common' },
      { name: 'Sitrus Berry', effect: 'Restores 25% HP', rarity: 'Uncommon' },
      { name: 'Pecha Berry', effect: 'Cures Poison', rarity: 'Common' },
      { name: 'Cheri Berry', effect: 'Cures Paralysis', rarity: 'Common' },
      { name: 'Chesto Berry', effect: 'Cures Sleep', rarity: 'Common' },
      { name: 'Rawst Berry', effect: 'Cures Burn', rarity: 'Common' },
      { name: 'Aspear Berry', effect: 'Cures Freeze', rarity: 'Common' },
      { name: 'Persim Berry', effect: 'Cures Confusion', rarity: 'Uncommon' }
    ];
  }
}