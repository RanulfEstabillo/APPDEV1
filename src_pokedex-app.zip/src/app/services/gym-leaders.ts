import { Injectable } from '@angular/core';

export interface GymLeader {
  name: string;
  type: string;
  badge: string;
  location: string;
  route: string;
  pokemonTeam: { 
    name: string; 
    type: string; 
    level: number;
    spriteUrl: string; // Add sprite URL for each Pokémon
  }[];
  bio: string;
  battleTips: string[];
  leaderImage?: string; // Add leader image URL
  badgeImage?: string;  // Add badge image URL
}

@Injectable({
  providedIn: 'root'
})
export class GymLeadersService {
  constructor() { }

  getGymLeaders(): GymLeader[] {
    return [
      {
        name: 'Falkner',
        type: 'Flying',
        badge: 'Zephyr Badge',
        location: 'Violet City',
        route: '/falkner',
        pokemonTeam: [
          {
            name: 'Pidgey', 
            type: 'Normal/Flying', 
            level: 7,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/16.png'
          },
          { 
            name: 'Pidgeotto', 
            type: 'Normal/Flying', 
            level: 9,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/17.png'
          }
        ],
        bio: 'Falkner is the Violet City Gym Leader, following in the footsteps of his father. He specializes in Flying-type Pokémon and is known for his calm and collected battle style.',
        battleTips: [
          'Use Electric-type moves for super effective damage',
          'Rock-type Pokémon are immune to Flying-type moves',
          'Ice-type moves are also effective against Flying-types'
        ]
      },
      {
        name: 'Bugsy',
        type: 'Bug',
        badge: 'Hive Badge',
        location: 'Azalea Town',
        route: '/bugsy',
        leaderImage: '/assets/images/gym-leaders/bugsy.jpg',
        badgeImage: '/assets/images/badges/hive-badge.png',
        pokemonTeam: [
          { 
            name: 'Metapod', 
            type: 'Bug', 
            level: 14,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/11.png'
          },
          { 
            name: 'Kakuna', 
            type: 'Bug/Poison', 
            level: 14,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/14.png'
          },
          { 
            name: 'Scyther', 
            type: 'Bug/Flying', 
            level: 16,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/123.png'
          }
        ],
        bio: 'Bugsy is the Azalea Town Gym Leader and a recognized Bug-type Pokémon expert despite his young age.',
        battleTips: [
          'Use Fire-type moves for 4x super effective damage',
          'Flying-type and Rock-type moves are also very effective',
          'Watch out for status conditions like Poison and Paralysis'
        ]
      },
      {
        name: 'Whitney',
        type: 'Normal',
        badge: 'Plain Badge',
        location: 'Goldenrod City',
        route: '/whitney',
        leaderImage: '/assets/images/gym-leaders/whitney.jpg',
        badgeImage: '/assets/images/badges/plain-badge.png',
        pokemonTeam: [
          { 
            name: 'Clefairy', 
            type: 'Normal', 
            level: 18,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/35.png'
          },
          { 
            name: 'Miltank', 
            type: 'Normal', 
            level: 20,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/241.png'
          }
        ],
        bio: 'Whitney is the Goldenrod City Gym Leader known for her powerful Miltank.',
        battleTips: [
          'Use Fighting-type moves for super effective damage',
          'Ghost-type Pokémon are immune to Normal-type moves',
          'Stop Miltank\'s Rollout early before it gains power'
        ]
      },
      {
        name: 'Morty',
        type: 'Ghost',
        badge: 'Fog Badge',
        location: 'Ecruteak City',
        route: '/morty',
        leaderImage: '/assets/images/gym-leaders/morty.jpg',
        badgeImage: '/assets/images/badges/fog-badge.png',
        pokemonTeam: [
          { 
            name: 'Gastly', 
            type: 'Ghost/Poison', 
            level: 21,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/92.png'
          },
          { 
            name: 'Haunter', 
            type: 'Ghost/Poison', 
            level: 21,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/93.png'
          },
          { 
            name: 'Haunter', 
            type: 'Ghost/Poison', 
            level: 23,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/93.png'
          },
          { 
            name: 'Gengar', 
            type: 'Ghost/Poison', 
            level: 25,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/94.png'
          }
        ],
        bio: 'Morty is the Ecruteak City Gym Leader who admires the legendary Pokémon Ho-Oh.',
        battleTips: [
          'Use Ghost-type and Dark-type moves for super effective damage',
          'Normal and Fighting moves have no effect on Ghost-types',
          'Bring Pokémon that can\'t be poisoned'
        ]
      },
      {
        name: 'Chuck',
        type: 'Fighting',
        badge: 'Storm Badge',
        location: 'Cianwood City',
        route: '/chuck',
        leaderImage: '/assets/images/gym-leaders/chuck.jpg',
        badgeImage: '/assets/images/badges/storm-badge.png',
        pokemonTeam: [
          { 
            name: 'Primeape', 
            type: 'Fighting', 
            level: 27,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/57.png'
          },
          { 
            name: 'Poliwrath', 
            type: 'Water/Fighting', 
            level: 30,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/62.png'
          }
        ],
        bio: 'Chuck is the Cianwood City Gym Leader, a tough martial artist who trains with his Pokémon.',
        battleTips: [
          'Use Flying-type and Psychic-type moves for super effective damage',
          'Fairy-type moves are also very effective against Fighting-types',
          'Watch out for Poliwrath\'s Hypnosis and Dynamic Punch combo'
        ]
      },
      {
        name: 'Jasmine',
        type: 'Steel',
        badge: 'Mineral Badge',
        location: 'Olivine City',
        route: '/jasmine',
        leaderImage: '/assets/images/gym-leaders/jasmine.jpg',
        badgeImage: '/assets/images/badges/mineral-badge.png',
        pokemonTeam: [
          { 
            name: 'Magnemite', 
            type: 'Electric/Steel', 
            level: 30,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/81.png'
          },
          { 
            name: 'Magnemite', 
            type: 'Electric/Steel', 
            level: 30,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/81.png'
          },
          { 
            name: 'Steelix', 
            type: 'Steel/Ground', 
            level: 35,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/208.png'
          }
        ],
        bio: 'Jasmine is the Olivine City Gym Leader, a quiet and caring trainer who looks after the sick Ampharos at the lighthouse.',
        battleTips: [
          'Use Fire-type, Fighting-type, and Ground-type moves for super effective damage',
          'Steelix is weak to Fire, Water, Fighting, and Ground moves',
          'Electric and Normal moves are not very effective against Steel-types'
        ]
      },
      {
        name: 'Pryce',
        type: 'Ice',
        badge: 'Glacier Badge',
        location: 'Mahogany Town',
        route: '/pryce',
        leaderImage: '/assets/images/gym-leaders/pryce.jpg',
        badgeImage: '/assets/images/badges/glacier-badge.png',
        pokemonTeam: [
          { 
            name: 'Seel', 
            type: 'Water', 
            level: 27,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/86.png'
          },
          { 
            name: 'Dewgong', 
            type: 'Water/Ice', 
            level: 29,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/87.png'
          },
          { 
            name: 'Piloswine', 
            type: 'Ice/Ground', 
            level: 31,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/221.png'
          }
        ],
        bio: 'Pryce is the Mahogany Town Gym Leader, an elderly man who has been training Pokémon for over 50 years.',
        battleTips: [
          'Use Fire-type, Fighting-type, Rock-type, and Steel-type moves for super effective damage',
          'Ice-types are weak to many types, making them vulnerable',
          'Watch out for Ice Beam\'s freezing chance'
        ]
      },
      {
        name: 'Clair',
        type: 'Dragon',
        badge: 'Rising Badge',
        location: 'Blackthorn City',
        route: '/clair',
        leaderImage: '/assets/images/gym-leaders/clair.jpg',
        badgeImage: '/assets/images/badges/rising-badge.png',
        pokemonTeam: [
          { 
            name: 'Dragonair', 
            type: 'Dragon', 
            level: 37,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/148.png'
          },
          { 
            name: 'Dragonair', 
            type: 'Dragon', 
            level: 37,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/148.png'
          },
          { 
            name: 'Dragonair', 
            type: 'Dragon', 
            level: 40,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/148.png'
          },
          { 
            name: 'Kingdra', 
            type: 'Water/Dragon', 
            level: 42,
            spriteUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/230.png'
          }
        ],
        bio: 'Clair is the Blackthorn City Gym Leader and cousin of the Elite Four member Lance.',
        battleTips: [
          'Use Ice-type and Dragon-type moves for super effective damage',
          'Fairy-type Pokémon are immune to Dragon-type moves',
          'Kingdra is only weak to Dragon-type moves'
        ]
      }
    ];
  }

  getGymLeaderByName(name: string): GymLeader | undefined {
    return this.getGymLeaders().find(leader => 
      leader.name.toLowerCase() === name.toLowerCase()
    );
  }

  // Helper method to get Pokémon sprite by name
  getPokemonSpriteUrl(pokemonName: string): string {
    const spriteMap: { [key: string]: string } = {
      'Pidgey': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/16.png',
      'Pidgeotto': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/17.png',
      'Metapod': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/11.png',
      'Kakuna': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/14.png',
      'Scyther': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/123.png',
      'Clefairy': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/35.png',
      'Miltank': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/241.png',
      'Gastly': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/92.png',
      'Haunter': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/93.png',
      'Gengar': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/94.png',
      'Primeape': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/57.png',
      'Poliwrath': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/62.png',
      'Magnemite': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/81.png',
      'Steelix': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/208.png',
      'Seel': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/86.png',
      'Dewgong': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/87.png',
      'Piloswine': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/221.png',
      'Dragonair': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/148.png',
      'Kingdra': 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/230.png'
    };
    
    return spriteMap[pokemonName] || 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/0.png';
  }
}