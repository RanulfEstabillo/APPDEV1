import { TestBed } from '@angular/core/testing';

import { Berries } from './berries';

describe('Berries', () => {
  let service: Berries;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Berries);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
