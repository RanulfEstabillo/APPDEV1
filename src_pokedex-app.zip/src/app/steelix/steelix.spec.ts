import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Steelix } from './steelix';

describe('Steelix', () => {
  let component: Steelix;
  let fixture: ComponentFixture<Steelix>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Steelix]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Steelix);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
