import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { MatDividerModule } from '@angular/material/divider';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { Pokemon } from '../services/pokemon';

@Component({
  selector: 'app-steelix',
  standalone: true,
  imports: [CommonModule, MatDividerModule, MatCardModule, MatListModule],
  templateUrl: './steelix.html', // or './steelix.component.html'
  styleUrls: ['./steelix.css'] // or './steelix.component.css'
})
export class SteelixComponent implements OnInit {
  pokemon: Pokemon | null = null;
  isLoading: boolean = true;
  error: string | null = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get<Pokemon>('https://pokeapi.co/api/v2/pokemon/steelix').subscribe({
      next: (response) => {
        this.pokemon = response;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error:', error);
        this.error = 'Failed to load Pokémon data';
        this.isLoading = false;
      }
    });
  }
}