import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatGridListModule } from '@angular/material/grid-list';
import { TyphlosionComponent } from '../typhlosion/typhlosion';
import { AmpharosComponent } from '../ampharos/ampharos';
import { EspeonComponent } from '../espeon/espeon';
import { UmbreonComponent } from '../umbreon/umbreon';
import { SteelixComponent } from '../steelix/steelix';
import { KingdraComponent } from '../kingdra/kingdra';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-favorite-pokemon',
  standalone: true,
  imports: [
    CommonModule,
    MatGridListModule,
    TyphlosionComponent,
    AmpharosComponent,
    EspeonComponent,
    UmbreonComponent,
    SteelixComponent,
    KingdraComponent,
    RouterModule
  ],
  templateUrl: './favorite-pokemon.html',
  styleUrls: ['./favorite-pokemon.css']
})
export class FavoritePokemonComponent {}