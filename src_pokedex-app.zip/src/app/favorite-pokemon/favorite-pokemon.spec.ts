import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FavoritePokemon } from './favorite-pokemon';

describe('FavoritePokemon', () => {
  let component: FavoritePokemon;
  let fixture: ComponentFixture<FavoritePokemon>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FavoritePokemon]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FavoritePokemon);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
