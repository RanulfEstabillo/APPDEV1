import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LegendaryPokemonService, Pokemon } from '../services/legendary-pokemon';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-pokemon-list, RouterModule',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pokemon-list.html',
  styleUrls: ['./pokemon-list.css']
})
export class PokemonListComponent implements OnInit {
  kantoLegendaries: Pokemon[] = [];
  johtoLegendaries: Pokemon[] = [];

  constructor(private pokemonService: LegendaryPokemonService) {}

  ngOnInit(): void {
    this.kantoLegendaries = this.pokemonService.getKantoLegendaries();
    this.johtoLegendaries = this.pokemonService.getJohtoLegendaries();
  }
}