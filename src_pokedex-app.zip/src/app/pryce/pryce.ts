import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Pokemon {
  name: string;
  type: string;
  level: number;
}

@Component({
  selector: 'app-pryce',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './pryce.html',
  styleUrls: ['./pryce.css']
})
export class PryceComponent {
  pokemonTeam: Pokemon[] = [
    { name: 'Seel', type: 'Water', level: 27 },
    { name: 'Dewgong', type: 'Water/Ice', level: 29 },
    { name: 'Piloswine', type: 'Ice/Ground', level: 31 }
  ];
}