import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Pokemon {
  name: string;
  type: string;
  level: number;
}

@Component({
  selector: 'app-bugsy',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './bugsy.html',
  styleUrls: ['./bugsy.css']
})
export class BugsyComponent {
  pokemonTeam: Pokemon[] = [
    { name: 'Metapod', type: 'Bug', level: 14 },
    { name: 'Kakuna', type: 'Bug/Poison', level: 14 },
    { name: 'Scyther', type: 'Bug/Flying', level: 16 }
  ];
}