import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TrainerService, Trainer } from '../services/trainer'; // Fixed path
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-trainer-form',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, RouterModule],
  templateUrl: './trainer-form.html', // Fixed template name
  styleUrls: ['./trainer-form.css']   // Fixed style name
})
export class TrainerFormComponent {
  trainerForm = new FormGroup({
    name: new FormControl('', [Validators.required, Validators.minLength(2)]),
    age: new FormControl('', [Validators.required, Validators.min(10), Validators.max(100)]),
    address: new FormControl('', [Validators.required, Validators.minLength(5)]),
    favoritePokemon: new FormControl('', [Validators.required]),
    pokemonTeam: new FormControl('', [Validators.required])
  });

  constructor(private trainerService: TrainerService) {}

  get trainers(): Trainer[] {
    return this.trainerService.getTrainers();
  }

  onSubmit(): void {
    if (this.trainerForm.valid) {
      const formValue = this.trainerForm.getRawValue();
      const pokemonTeam = formValue.pokemonTeam?.split(',').map(p => p.trim()).filter(p => p) || [];
      
      const trainer: Trainer = {
        name: formValue.name || '',
        age: formValue.age || '',
        address: formValue.address || '',
        favoritePokemon: formValue.favoritePokemon || '',
        pokemonTeam: pokemonTeam
      };

      this.trainerService.addTrainer(trainer);
      this.trainerForm.reset();
    }
  }

  getFieldError(fieldName: string): string {
    const field = this.trainerForm.get(fieldName);
    if (field?.errors && field.touched) {
      if (field.errors['required']) return 'This field is required';
      if (field.errors['minlength']) return `Minimum length is ${field.errors['minlength'].requiredLength}`;
      if (field.errors['min']) return `Minimum age is ${field.errors['min'].min}`;
      if (field.errors['max']) return `Maximum age is ${field.errors['max'].max}`;
    }
    return '';
  }
}