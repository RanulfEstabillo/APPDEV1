import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { GymLeadersService, GymLeader } from '../services/gym-leaders';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-gym-leader-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './gym-leader-list.html',
  styleUrls: ['./gym-leader-list.css']
})
export class GymLeaderListComponent implements OnInit {
  gymLeaders: GymLeader[] = [];

  constructor(
    private gymLeadersService: GymLeadersService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.gymLeaders = this.gymLeadersService.getGymLeaders();
  }

  navigateToLeader(route: string): void {
    this.router.navigate([route]);
  }
}