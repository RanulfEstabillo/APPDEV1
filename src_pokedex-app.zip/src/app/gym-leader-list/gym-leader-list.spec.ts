import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GymLeaderList } from './gym-leader-list';

describe('GymLeaderList', () => {
  let component: GymLeaderList;
  let fixture: ComponentFixture<GymLeaderList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GymLeaderList]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GymLeaderList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
