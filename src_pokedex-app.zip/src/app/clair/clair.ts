import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Pokemon {
  name: string;
  type: string;
  level: number;
}

@Component({
  selector: 'app-clair',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './clair.html',
  styleUrls: ['./clair.css']
})
export class ClairComponent {
  pokemonTeam: Pokemon[] = [
    { name: 'Dragonair', type: 'Dragon', level: 37 },
    { name: 'Dragonair', type: 'Dragon', level: 37 },
    { name: 'Dragonair', type: 'Dragon', level: 40 },
    { name: 'Kingdra', type: 'Water/Dragon', level: 42 }
  ];
}