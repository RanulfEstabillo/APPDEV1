import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Pokemon {
  name: string;
  type: string;
  level: number;
}

@Component({
  selector: 'app-whitney',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './whitney.html',
  styleUrls: ['./whitney.css']
})
export class WhitneyComponent {
  pokemonTeam: Pokemon[] = [
    { name: 'Clefairy', type: 'Normal', level: 18 },
    { name: 'Miltank', type: 'Normal', level: 20 }
  ];
}