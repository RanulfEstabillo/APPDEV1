import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Pokemon {
  name: string;
  type: string;
  level: number;
}

@Component({
  selector: 'app-chuck',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './chuck.html',
  styleUrls: ['./chuck.css']
})
export class ChuckComponent {
  pokemonTeam: Pokemon[] = [
    { name: 'Primeape', type: 'Fighting', level: 27 },
    { name: 'Poliwrath', type: 'Water/Fighting', level: 30 }
  ];
}