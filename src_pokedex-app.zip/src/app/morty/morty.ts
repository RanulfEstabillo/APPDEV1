import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Pokemon {
  name: string;
  type: string;
  level: number;
}

@Component({
  selector: 'app-morty',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './morty.html',
  styleUrls: ['./morty.css']
})
export class MortyComponent {
  pokemonTeam: Pokemon[] = [
    { name: 'Gastly', type: 'Ghost/Poison', level: 21 },
    { name: 'Haunter', type: 'Ghost/Poison', level: 21 },
    { name: 'Haunter', type: 'Ghost/Poison', level: 23 },
    { name: 'Gengar', type: 'Ghost/Poison', level: 25 }
  ];
}