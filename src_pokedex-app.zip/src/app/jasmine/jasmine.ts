import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Pokemon {
  name: string;
  type: string;
  level: number;
}

@Component({
  selector: 'app-jasmine',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './jasmine.html',
  styleUrls: ['./jasmine.css']
})
export class JasmineComponent {
  pokemonTeam: Pokemon[] = [
    { name: 'Magnemite', type: 'Electric/Steel', level: 30 },
    { name: 'Magnemite', type: 'Electric/Steel', level: 30 },
    { name: 'Steelix', type: 'Steel/Ground', level: 35 }
  ];
}