import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Kingdra } from './kingdra';

describe('Kingdra', () => {
  let component: Kingdra;
  let fixture: ComponentFixture<Kingdra>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Kingdra]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Kingdra);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
