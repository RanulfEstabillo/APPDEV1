import { Component, OnInit } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { PokeballsService, Pokeball } from '../services/pokeballs';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-pokeballs',
  standalone: true,
  imports: [MatTableModule, RouterModule],
  templateUrl: './pokeballs.html',
  styleUrls: ['./pokeballs.css']
})
export class PokeballsComponent implements OnInit {
  dataSource: Pokeball[] = [];
  displayedColumns: string[] = ['name', 'catchRate', 'description'];

  constructor(private pokeballsService: PokeballsService) {}

  ngOnInit(): void {
    this.dataSource = this.pokeballsService.getPokeballs();
  }
}